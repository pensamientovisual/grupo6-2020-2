/*
Aquí van los datos de las regiones correspondientes
ARICA Y PARINACOTA ES LA VARIABLE XV
*/

var I=[{"habitantes":"319429", "PeSD":"43469","establecimientos":"45"}];
var II=[{"habitantes":"552615", "PeSD":"43568","establecimientos":"24"}];
var III=[{"habitantes":"271666", "PeSD":"52122","establecimientos":"26"}];
var IV=[{"habitantes":"731729", "PeSD":"121220","establecimientos":"125"}];
var V=[{"habitantes":"1768137", "PeSD":"260949","establecimientos":"35"}];
var VI=[{"habitantes":"886876", "PeSD":"176870","establecimientos":"123"}];
var VII=[{"habitantes":"1002906", "PeSD":"164648","establecimientos":"132"}];
var VIII=[{"habitantes":"2004826", "PeSD":"366887","establecimientos":"281"}];
var IX=[{"habitantes":"955913", "PeSD":"128184","establecimientos":"69"}];
var X=[{"habitantes":"835660", "PeSD":"140765","establecimientos":"100"}];
var XI=[{"habitantes":"99400", "PeSD":"11178","establecimientos":"9"}];
var RM=[{"habitantes":"6893613", "PeSD":"1188757","establecimientos":"743"}];
var XII=[{"habitantes":"146046", "PeSD":"29936","establecimientos":"16"}];
var XIV=[{"habitantes":"360853", "PeSD":"70498","establecimientos":"44"}];
var XV=[{"habitantes":"161668", "PeSD":"37767","establecimientos":"35"}];