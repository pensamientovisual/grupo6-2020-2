var buin =
[
    { group: "Buin" ,category: "Discapacidad Intelectual", count: 4},
    { group: "Buin" ,category: "Problema de Aprendizaje", count: 1},
    { group: "Buin" ,category: "Discapacida Visual", count: 12},
    { group: "Buin" ,category: "Problemas de audición y lenguaje", count: 15},
];
var calera =
[
    { group: "C. de Tango" ,category: "Discapacidad Intelectual", count: 1},
    { group: "C. de Tango" ,category: "Problema de Aprendizaje", count: 0},
    { group: "C. de Tango" ,category: "Discapacida Visual", count: 0},
    { group: "C. de Tango" ,category: "Problemas de audición y lenguaje", count: 3},
];
var cerrillos=
[
    { group: "Cerrillos" ,category: "Discapacidad Intelectual", count: 4},
    { group: "Cerrillos" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Cerrillos" ,category: "Discapacida Visual", count: 0},
    { group: "Cerrillos" ,category: "Problemas de audición y lenguaje", count: 9},
];
var cerro =
[
    { group: "Cerro Navia" ,category: "Problemas de audición y lenguaje", count: 6},
    { group: "Cerro Navia" ,category: "Discapacida Visual", count: 0},
    { group: "Cerro Navia" ,category: "Problema de Aprendizaje", count: 1},
    { group: "Cerro Navia" ,category: "Discapacidad Intelectual", count: 5},
];
var colina =
[
    { group: "Colina" ,category: "Problemas de audición y lenguaje", count: 9+1},
    { group: "Colina" ,category: "Discapacida Visual", count: 0},
    { group: "Colina" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Colina" ,category: "Discapacidad Intelectual", count: 6},
];
var conchali =
[
    { group: "Conchalí" ,category: "Problemas de audición y lenguaje", count: 12},
    { group: "Conchalí" ,category: "Discapacida Visual", count: 0},
    { group: "Conchalí" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Conchalí" ,category: "Discapacidad Intelectual", count: 8},
];
var curacavi =
[
    { group: "Curacaví" ,category: "Problemas de audición y lenguaje", count: 2},
    { group: "Curacaví" ,category: "Discapacida Visual", count: 0},
    { group: "Curacaví" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Curacaví" ,category: "Discapacidad Intelectual", count: 1}, 
];
var bosque =
[
    { group: "El Bosque" ,category: "Problemas de audición y lenguaje", count: 29+1+1},
    { group: "El Bosque" ,category: "Discapacida Visual", count: 0},
    { group: "El Bosque" ,category: "Problema de Aprendizaje", count: 1},
    { group: "El Bosque" ,category: "Discapacidad Intelectual", count: 8},
];
var monte =
[
    { group: "El Monte" ,category: "Problemas de audición y lenguaje", count: 7},
    { group: "El Monte" ,category: "Discapacida Visual", count: 0},
    { group: "El Monte" ,category: "Problema de Aprendizaje", count: 0},
    { group: "El Monte" ,category: "Discapacidad Intelectual", count: 2},
];
var central =
[
    { group: "Est. Central " ,category: "Discapacidad Intelectual", count: 1},
    { group: "Est. Central " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Est. Central " ,category: "Discapacida Visual", count: 0},
    { group: "Est. Central " ,category: "Problemas de audición y lenguaje", count: 13},
];
var huechu =
[
    { group: "Huechuraba " ,category: "Discapacidad Intelectual", count: 1},
    { group: "Huechuraba " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Huechuraba " ,category: "Discapacida Visual", count: 0},
    { group: "Huechuraba " ,category: "Problemas de audición y lenguaje", count: 6},
];
var ind =
[
    { group: "Independ. " ,category: "Discapacidad Intelectual", count: 0},
    { group: "Independ. " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Independ. " ,category: "Discapacida Visual", count: 0},
    { group: "Independ. " ,category: "Problemas de audición y lenguaje", count: 4},
];
var isla =
[
    { group: "I. de Maipo" ,category: "Discapacidad Intelectual", count: 0},
    { group: "I. de Maipo" ,category: "Problema de Aprendizaje", count: 0},
    { group: "I. de Maipo" ,category: "Discapacida Visual", count: 0},
    { group: "I. de Maipo" ,category: "Problemas de audición y lenguaje", count: 5},
];
var lacisterna = 
[
    { group: "La Cisterna " ,category: "Discapacidad Intelectual", count: 7},
    { group: "La Cisterna " ,category: "Problema de Aprendizaje", count: 0},
    { group: "La Cisterna " ,category: "Discapacida Visual", count: 1},
    { group: "La Cisterna " ,category: "Problemas de audición y lenguaje", count: 10},
];
var laflorida = 
[
    { group: "La Florida " ,category: "Discapacidad Intelectual", count: 11},
    { group: "La Florida " ,category: "Problema de Aprendizaje", count: 3},
    { group: "La Florida " ,category: "Discapacida Visual", count: 0},
    { group: "La Florida " ,category: "Problemas de audición y lenguaje", count: 38},
];
var lagranja = 
[
    { group: "La Granja " ,category: "Discapacidad Intelectual", count: 5},
    { group: "La Granja " ,category: "Problema de Aprendizaje", count: 0},
    { group: "La Granja " ,category: "Discapacida Visual", count: 0},
    { group: "La Granja " ,category: "Problemas de audición y lenguaje", count: 16},
];
var lapintana = 
[
    { group: "La Pintana " ,category: "Discapacidad Intelectual", count: 5},
    { group: "La Pintana " ,category: "Problema de Aprendizaje", count: 0},
    { group: "La Pintana " ,category: "Discapacida Visual", count: 0},
    { group: "La Pintana " ,category: "Problemas de audición y lenguaje", count: 21},
];
var lareina = 
[
    { group: "La Reina " ,category: "Discapacidad Intelectual", count: 0},
    { group: "La Reina " ,category: "Problema de Aprendizaje", count: 1},
    { group: "La Reina " ,category: "Discapacida Visual", count: 0},
    { group: "La Reina " ,category: "Problemas de audición y lenguaje", count: 4+1},
];
var lampa =
[
    { group: "Lampa " ,category: "Discapacidad Intelectual", count: 5},
    { group: "Lampa " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Lampa " ,category: "Discapacida Visual", count: 0},
    { group: "Lampa " ,category: "Problemas de audición y lenguaje", count: 15},
];
var lascondes = 
[
    { group: "Las Condes " ,category: "Discapacidad Intelectual", count: 1},
    { group: "Las Condes " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Las Condes " ,category: "Discapacida Visual", count: 0},
    { group: "Las Condes " ,category: "Problemas de audición y lenguaje", count: 4},
];
var lobarnechea = 
[
    { group: "Lo Barnechea " ,category: "Discapacidad Intelectual", count: 1},
    { group: "Lo Barnechea " ,category: "Problema de Aprendizaje", count: 1},
    { group: "Lo Barnechea " ,category: "Discapacida Visual", count: 0},
    { group: "Lo Barnechea " ,category: "Problemas de audición y lenguaje", count: 3},
];
var loespejo = 
[
    { group: "Lo Espejo " ,category: "Discapacidad Intelectual", count: 3},
    { group: "Lo Espejo " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Lo Espejo " ,category: "Discapacida Visual", count: 0},
    { group: "Lo Espejo " ,category: "Problemas de audición y lenguaje", count: 6},
];
var loprado = 
[
    { group: "Lo Prado " ,category: "Discapacidad Intelectual", count: 2},
    { group: "Lo Prado " ,category: "Problema de Aprendizaje", count: 1},
    { group: "Lo Prado " ,category: "Discapacida Visual", count: 0},
    { group: "Lo Prado " ,category: "Problemas de audición y lenguaje", count: 7},
];
var macul = 
[
    { group: "Macul " ,category: "Discapacidad Intelectual", count: 6},
    { group: "Macul " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Macul " ,category: "Discapacida Visual", count: 0},
    { group: "Macul " ,category: "Problemas de audición y lenguaje", count: 0},
];
var maipu = 
[
    { group: "Maipú" ,category: "Discapacidad Intelectual", count: 0},
    { group: "Maipú" ,category: "Problema de Aprendizaje", count: 3},
    { group: "Maipú" ,category: "Discapacida Visual", count: 0},
    { group: "Maipú" ,category: "Problemas de audición y lenguaje", count: 50+1},
];
var mariapinto =
[
    { group: "María Pinto " ,category: "Discapacidad Intelectual", count: 0},
    { group: "María Pinto " ,category: "Problema de Aprendizaje", count: 0},
    { group: "María Pinto " ,category: "Discapacida Visual", count: 0},
    { group: "María Pinto " ,category: "Problemas de audición y lenguaje", count: 1}
];
var melipilla =
[
    { group: "Melipilla " ,category: "Discapacidad Intelectual", count: 3},
    { group: "Melipilla " ,category: "Problema de Aprendizaje", count: 0},
    { group: "Melipilla " ,category: "Discapacida Visual", count: 0},
    { group: "Melipilla " ,category: "Problemas de audición y lenguaje", count: 12},
];
var ñuñoa =
[
    { group: "Ñuñoa" ,category: "Discapacidad Intelectual", count: 6},
    { group: "Ñuñoa" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Ñuñoa" ,category: "Discapacida Visual", count: 2},
    { group: "Ñuñoa" ,category: "Problemas de audición y lenguaje", count: 5+2},
];
var padrehurtado =
[
    { group: "P. Hurtado" ,category: "Discapacidad Intelectual", count: 4},
    { group: "P. Hurtado" ,category: "Problema de Aprendizaje", count: 0},
    { group: "P. Hurtado" ,category: "Discapacida Visual", count: 0},
    { group: "P. Hurtado" ,category: "Problemas de audición y lenguaje", count: 12},
];
var paine =
[
     
    { group: "Paine" ,category: "Discapacidad Intelectual", count: 2},
    { group: "Paine" ,category: "Problema de Aprendizaje", count: 1},
    { group: "Paine" ,category: "Discapacida Visual", count: 0},
    { group: "Paine" ,category: "Problemas de audición y lenguaje", count: 9},
];
var pac =
[
    { group: "PAC" ,category: "Discapacidad Intelectual", count: 4},
    { group: "PAC" ,category: "Problema de Aprendizaje", count: 0},
    { group: "PAC" ,category: "Discapacida Visual", count: 0},
    { group: "PAC" ,category: "Problemas de audición y lenguaje", count: 9},
];
var peñaflor =
[
    { group: "Peñaflor" ,category: "Discapacidad Intelectual", count: 2},
    { group: "Peñaflor" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Peñaflor" ,category: "Discapacida Visual", count: 0},
    { group: "Peñaflor" ,category: "Problemas de audición y lenguaje", count: 16},
];
var peñalolen =
[
    { group: "Peñalolén" ,category: "Discapacidad Intelectual", count: 5},
    { group: "Peñalolén" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Peñalolén" ,category: "Discapacida Visual", count: 0},
    { group: "Peñalolén" ,category: "Problemas de audición y lenguaje", count: 14},
];
var pirque =
[
    { group: "Pirque" ,category: "Discapacidad Intelectual", count: 0},
    { group: "Pirque" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Pirque" ,category: "Discapacida Visual", count: 0},
    { group: "Pirque" ,category: "Problemas de audición y lenguaje", count: 2},
];
var providencia =
[
    { group: "Providencia" ,category: "Discapacidad Intelectual", count: 0},
    { group: "Providencia" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Providencia" ,category: "Discapacida Visual", count: 0},
    { group: "Providencia" ,category: "Problemas de audición y lenguaje", count: 2},
];
var pudahuel =
[
    { group: "Pudahuel" ,category: "Discapacidad Intelectual", count: 4},
    { group: "Pudahuel" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Pudahuel" ,category: "Discapacida Visual", count: 0},
    { group: "Pudahuel" ,category: "Problemas de audición y lenguaje", count: 16+1},
];
var puentealto =
[
    { group: "Puente Alto" ,category: "Discapacidad Intelectual", count: 15},
    { group: "Puente Alto" ,category: "Problema de Aprendizaje", count: 1},
    { group: "Puente Alto" ,category: "Discapacida Visual", count: 0},
    { group: "Puente Alto" ,category: "Problemas de audición y lenguaje", count: 50+1},
];
var quilicura =
[
    { group: "Quilicura" ,category: "Discapacidad Intelectual", count: 4},
    { group: "Quilicura" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Quilicura" ,category: "Discapacida Visual", count: 0},
    { group: "Quilicura" ,category: "Problemas de audición y lenguaje", count: 17},
];
var quintanormal =
[
    { group: "Quinta Normal" ,category: "Discapacidad Intelectual", count: 6},
    { group: "Quinta Normal" ,category: "Problema de Aprendizaje", count: 3},
    { group: "Quinta Normal" ,category: "Discapacida Visual", count: 0},
    { group: "Quinta Normal" ,category: "Problemas de audición y lenguaje", count: 18},
];
var recoleta =
[
    { group: "Recoleta" ,category: "Discapacidad Intelectual", count: 5},
    { group: "Recoleta" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Recoleta" ,category: "Discapacida Visual", count: 0},
    { group: "Recoleta" ,category: "Problemas de audición y lenguaje", count: 11},
];
var renca =
[
    { group: "Renca" ,category: "Discapacidad Intelectual", count: 4},
    { group: "Renca" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Renca" ,category: "Discapacida Visual", count: 0},
    { group: "Renca" ,category: "Problemas de audición y lenguaje", count: 12},
];
var sanbernardo =
[
    { group: "San Bernardo" ,category: "Discapacidad Intelectual", count: 10},
    { group: "San Bernardo" ,category: "Problema de Aprendizaje", count: 2},
    { group: "San Bernardo" ,category: "Discapacida Visual", count: 0},
    { group: "San Bernardo" ,category: "Problemas de audición y lenguaje", count: 38},
];
var sanjoaquin =
[
    { group: "San Joaquín" ,category: "Discapacidad Intelectual", count: 2},
    { group: "San Joaquín" ,category: "Problema de Aprendizaje", count: 0},
    { group: "San Joaquín" ,category: "Discapacida Visual", count: 0},
    { group: "San Joaquín" ,category: "Problemas de audición y lenguaje", count: 9+1},
];
var sanjose =
[
    { group: "Jose de Maipo" ,category: "Discapacidad Intelectual", count: 0},
    { group: "Jose de Maipo" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Jose de Maipo" ,category: "Discapacida Visual", count: 0},
    { group: "Jose de Maipo" ,category: "Problemas de audición y lenguaje", count: 5},
];
var sanmiguel =
[
    { group: "San Miguel" ,category: "Discapacidad Intelectual", count: 1},
    { group: "San Miguel" ,category: "Problema de Aprendizaje", count: 1},
    { group: "San Miguel" ,category: "Discapacida Visual", count: 0},
    { group: "San Miguel" ,category: "Problemas de audición y lenguaje", count: 9},
];
var sanramon =
[
    { group: "San Ramón" ,category: "Discapacidad Intelectual", count: 3},
    { group: "San Ramón" ,category: "Problema de Aprendizaje", count: 0},
    { group: "San Ramón" ,category: "Discapacida Visual", count: 0},
    { group: "San Ramón" ,category: "Problemas de audición y lenguaje", count: 7},
];
var santiago =
[
    
    { group: "Santiago" ,category: "Discapacidad Intelectual", count: 3},
    { group: "Santiago" ,category: "Problema de Aprendizaje", count: 2},
    { group: "Santiago" ,category: "Discapacida Visual", count: 1},
    { group: "Santiago" ,category: "Problemas de audición y lenguaje", count: 8+3},
];
var talagante =
[
    { group: "Talagante" ,category: "Discapacidad Intelectual", count: 2},
    { group: "Talagante" ,category: "Problema de Aprendizaje", count: 1},
    { group: "Talagante" ,category: "Discapacida Visual", count: 0},
    { group: "Talagante" ,category: "Problemas de audición y lenguaje", count: 9},
];
var tiltil =
[
    
    { group: "Til Til" ,category: "Discapacidad Intelectual", count: 0},
    { group: "Til Til" ,category: "Problema de Aprendizaje", count: 0},
    { group: "Til Til" ,category: "Discapacida Visual", count: 0},
    { group: "Til Til" ,category: "Problemas de audición y lenguaje", count: 3},
]
var datafaltante=
[    
    
   
   
   
  
  
  
       
    

    
    
   
   
   
    
   
   

   
];

function DotMatrixChart(dataset,options){

    var dotRadius = options.dot_radius;
    var noOfCirclesInARow = options.no_of_circles_in_a_row;
    var dotPaddingLeft = options.dot_padding_left;
    var dotPaddingRight = options.dot_padding_right;
    var dotPaddingTop = options.dot_padding_top;
    var dotPaddingBottom = options.dot_padding_bottom;

    if(isNaN(dotRadius)){
        throw new Error("dot_radius must be a Number");
    }
    if(isNaN(noOfCirclesInARow)){
        throw new Error("no_of_circles_in_a_row must be a Number");
    }
    if(isNaN(dotPaddingLeft)){
        throw new Error("dot_padding_left must be a Number");
    }
    if(isNaN(dotPaddingRight)){
        throw new Error("dot_padding_right must be a Number");
    }
    if(isNaN(dotPaddingTop)){
        throw new Error("dot_padding_top must be a Number");
    }
    if(isNaN(dotPaddingBottom)){
        throw new Error("dot_padding_bottom must be a Number");
    }


    var flags = [], uniqueCategories = [], uniqueGroups=[], l = dataset.length, i;
    for( i=0; i<l; i++) {
        if( flags[dataset[i].category]) continue;
        flags[dataset[i].category] = true;
        uniqueCategories.push(dataset[i].category);
    }
    flags = [];
    for( i=0; i<l; i++) {
        if( flags[dataset[i].group]) continue;
        flags[dataset[i].group] = true;
        uniqueGroups.push(dataset[i].group);
    }

    var sumOfEveryGroup = {};
    for(var i=0;i<dataset.length;i++){
        if(sumOfEveryGroup[dataset[i]['group']] == null){
            sumOfEveryGroup[dataset[i]['group']] = 0;
        }
        sumOfEveryGroup[dataset[i]['group']] += dataset[i]['count'];
    }

    var maxNoOfLinesInGroup = 0;
    for(var group in sumOfEveryGroup){
        if(sumOfEveryGroup[group]/noOfCirclesInARow > maxNoOfLinesInGroup){
            maxNoOfLinesInGroup = Math.ceil(sumOfEveryGroup[group]/noOfCirclesInARow);
        }
    }

    var numberOfLines = maxNoOfLinesInGroup * uniqueGroups.length;

    var groupScale = d3.scale.ordinal().domain(uniqueGroups).rangePoints([0, uniqueGroups.length-1]);
    var categoryScale = d3.scale.ordinal().domain(uniqueCategories).rangePoints([0, uniqueCategories.length]);

    var color = d3.scale.ordinal().domain([4]).range(["#EBCB6E", "#da5da2", "#EEA767", "#53AD9F"]);

    // Set the dimensions of the canvas / graph
    var	margin = {top: dotRadius*10, right: dotRadius*150, bottom: dotRadius*10, left: dotRadius*15};

    height = numberOfLines * (dotRadius*2 + dotPaddingBottom + dotPaddingTop);
    width = (dotRadius*2 + dotPaddingLeft + dotPaddingRight) * noOfCirclesInARow;

    // Set the ranges
    var	xScale = d3.scale.linear().range([margin.left, width]);
    var	yScale = d3.scale.linear().range([height, margin.bottom]);

    var xAxis = d3.svg.axis()
          .scale(xScale)
          .orient("bottom");

    var yAxis = d3.svg.axis()
                .scale(yScale)
                .orient("left")
                .tickFormat(function (d) {
                    return uniqueGroups[d];
                })
                .ticks(uniqueGroups.length)
                .tickSize(-width+margin.left-(dotRadius*2), 0, 0)


    xScale.domain([0,noOfCirclesInARow]);
    yScale.domain([0,d3.max(dataset,function(d){return groupScale(d.group)+1;})]);

    //Create SVG element
    var svg = d3.select("#DotMatrixChart")
                .append("svg")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    //Create Y axis
    svg.append("g")
        .attr("transform", "translate(" + (margin.left - (dotRadius*2)) + ",0)")
        .attr("class", "y axis")
        .call(yAxis)
        .selectAll("text")
        .attr("y", -dotRadius*5)
        .attr("x", 0)
        .attr("dy", ".35em")
        .style("font-size", dotRadius*3 + "px")
        .attr("transform", "rotate(-90)")
        .style("text-anchor", "start");

    //Create Y axis
        svg
        .append("line")
        .attr("x1",width)
        .attr("y1",margin.top)
        .attr("x2",width)
        .attr("y2",height)
        .style("stroke","transparent")
        .style("stroke-width",1)

    var globalLineNoForGroup = {};
    var globalLineSizeForGroup = {};
    var globalDotXPosition = {};
    function generate_array(d){

        if(globalLineSizeForGroup[d.group] == null){
            globalLineSizeForGroup[d.group] = 0;
        }
        if(globalLineNoForGroup[d.group] == null){
            globalLineNoForGroup[d.group] = 0.5/(maxNoOfLinesInGroup);
        }
        if(globalDotXPosition[d.group] == null){
            globalDotXPosition[d.group] = 0;
        }

        var arr = new Array(d.count);
        for(var i=0;i<d.count;i++){

            if(globalLineSizeForGroup[d.group]!=0 && globalLineSizeForGroup[d.group] % noOfCirclesInARow == 0){
                globalLineNoForGroup[d.group] += 1/(maxNoOfLinesInGroup);
                globalDotXPosition[d.group]=1;
            }else{
                globalDotXPosition[d.group]+=1;
            }

            arr[i] = {y:groupScale(d.group)+globalLineNoForGroup[d.group],x: globalDotXPosition[d.group]-1, group:d.group,category:d.category};
            globalLineSizeForGroup[d.group] += 1;
        }
        return arr;
    }

    var groups = svg
       .selectAll("g.group")
       .data( dataset )
        .enter()
        .append('g')
        .attr("class", "group");

    var circleArray = groups.selectAll("g.circleArray")
    .data(function(d) {return generate_array(d);});

    circleArray.enter()
    .append('g')
    .attr("class", "circleArray")
    .append("circle")
    .style("fill",function(d){return color(d.category);})
    .attr("r", dotRadius*1.25)
    .attr("cx", function(d,i) {return xScale(d.x); })
    .attr("cy", function(d,i) { return yScale(d.y); });

    // add legend
    var legend = svg
    .selectAll(".legend")
    .data(uniqueCategories)
    .enter()
    .append("g")
    .attr("class", "legend")
    .attr("transform", "translate(" + 0  + "," + (margin.top+dotRadius) + ")");

    legend
      .append("circle")
      .attr("cx", width + dotRadius*4)
      .attr("cy", function(d,i){return i*dotRadius*4;})
      .attr("r", dotRadius)
      .style("fill", function(d) {
        return color(d);
      })

    legend
      .append("text")
      .attr("x", width + dotRadius*4 + dotRadius*3)
      .attr("text-anchor",'start')
      .attr("y", function(d,i){return i*dotRadius*4 + dotRadius;})
      .style("font-size", dotRadius*3 + "px")
      .text(function(d){return d});


    var tooltip = d3.select("body")
    .append('div')
    .attr('class', 'tooltip');

    tooltip.append('div')
    .attr('class', 'group');
    tooltip.append('div')
    .attr('class', 'category');

    svg.selectAll(".circleArray > circle")
    .on('mouseover', function(d,i) {

        tooltip.select('.group').html("<b>Comuna: " + d.group+ "</b>");
        tooltip.select('.category').html("<b>Establecimiento: " + d.category+ "</b>");

        tooltip.style('display', 'block');
        tooltip.style('opacity',2);

    })
    .on('mousemove', function(d) {
        tooltip.style('top', (d3.event.layerY + 10) + 'px')
        .style('left', (d3.event.layerX - 25) + 'px');
    })
    .on('mouseout', function() {
        tooltip.style('display', 'none');
        tooltip.style('opacity',0);
    });
}