# Grupo 6

- URL página: https://grupo6-pv-2020-2.herokuapp.com/

## Integración continua:
Cada vez que hagan un `push` a la rama `main` del repositorio (es decir, suban nuevo código), este se subirá automáticamente en el link que se menciona arriba.

Para que el deploy directo a la URL funcione, no deben editar/eliminar los siguientes archivos:
- `index.php`
- `composer.json`

Deben llamar a su página de inicio `index.html` (pueden editar el archivo ya existente).